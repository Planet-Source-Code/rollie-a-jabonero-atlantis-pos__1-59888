'Author: Rollie A. Jabonero
'Date Created: 04/07/05
'Email add: bluegues@yahoo.com
'Credits: None
'Comments: Please email me at bluegues@yahoo.com or call me at +63-917-5606867 or + 63-920-9260032



This is my first POS project here in Davao City, Philippines.

